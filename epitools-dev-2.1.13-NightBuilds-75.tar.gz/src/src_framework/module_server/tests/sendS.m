function sendS(oStream,str)
 
oStream.write(int8([str 10]))

