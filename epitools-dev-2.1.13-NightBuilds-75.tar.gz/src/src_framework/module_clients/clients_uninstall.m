function [ output_args ] = clients_remove( input_args )
%CLIENTS_REMOVE Summary of this function goes here
%   Detailed explanation goes here

% Check if argument passed is present in modules_available
% Retrieve path associated
% Check if path is present in src_analysis
% Remove it
% Update modules_available



end

