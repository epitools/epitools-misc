function [ output_args ] = clients_remove4queue( input_args )
%CLIENTS_REMOVE4QUEUE Summary of this function goes here
%   Detailed explanation goes here


end

