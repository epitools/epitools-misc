function [status, argout] = skeleton_func(input_args, varargin)
%SKELETON_FUNC This function convert segmented images into skeletons
% ------------------------------------------------------------------------------
% PREAMBLE
%
%
% INPUT
%   1. input_args:  variable containing the analysis object
%   2. varargin:    variable containing extra parameters for ref association
%                   during output formatting (might not be implemented)
%
% OUTPUT
%   1. status:  status elaboration (0  executed correctly; > 0 fatal error)
%   2. argout:  variable containing a structure with output objects, description
%               and ref association
%
% REFERENCES
%
% AUTHOR:   Alexander Tournier (alexander.tournier@cancer.org.uk)
%           Andreas Hoppe (A.Hoppe@kingston.ac.uk)
%           Davide Martin Heller (davide.heller@imls.uzh.ch)
%           Lorenzo Gatti (lorenzo.gatti@alumni.ethz.ch)
%
% DATE:    
%           07.05.16 V0.4 for EpiTools 3.0 beta
%
% LICENCE:
% License to use and modify this code is granted freely without warranty to all, as long as the
% original author is referenced and attributed as such. The original author maintains the right
% to be solely associated with this work.
%
% Copyright by A.Tournier, A. Hoppe, D. Heller, L.Gatti
% ------------------------------------------------------------------------------
%% Retrieve supplementary arguments
if (nargin<2); varargin(1) = {'SKELETONPATH'};varargin(2) = {'SETTINGS'};end
%% Procedure initialization
status = 1;
%% Retrieve parameter data
% it is more convenient to recall the setting file with as shorter variable
% name: stgModule
% TODO: input_args{strcmp(input_args(:,1),'SmoothingRadius'),2}
handleSettings = input_args{strcmp(input_args(:,1),'ExecutionSettingsHandle'),2};
execMessageUID = input_args{strcmp(input_args(:,1),'ExecutionMessageUID'),2};
%% Open Connection to Server
server_instances = getappdata(getappdata(0, 'hMainGui'), 'server_instances');
server = server_instances(2).ref;
%% Remapping
% it is more convenient to recall the setting file with a shorter variable
% name: stgModule 
stgObj = getVariable4Memory(handleSettings);
%load(DataSpecificsPath);
tmpStgObj = stgObj.analysis_modules.Skeletons.settings;
% -------------------------------------------------------------------------
% Log status of current application status
log2dev('******************* SKELETON GENERATION *******************','INFO');
log2dev('* Authors: A.Tournier, A. Hoppe, D. Heller, L.Gatti       * ','INFO');
log2dev('* Revision: 0.1 beta    $ Date: 2014/09/02 11:37:00       *','INFO');
log2dev('***********************************************************','INFO');
log2dev('Started skeleton analysis module', 'INFO');
% -------------------------------------------------------------------------      


log2dev('Exporting skeletons is evaluating the input data...','INFO',0,'hMainGui', 'statusbar',{0,5,1});

%local_use_corrections = 0;
%corrected_segmentation_file = 'none';
%if user decided to use the corrected segmentation results
if(isfield(tmpStgObj,'use_corrected_segmentation')) %backwards compatability
    if tmpStgObj.use_corrected_segmentation
    
        execTDep = {'RESEGMENTED_IMAGE'};
        [~,clabels] = RetrieveData2Load(execTDep);
        
        if isempty(clabels)
            log2dev('Manual corrected segmentation has not been found. Deselect the option [Use corrected segmentation]','INFO');
            return;
        else
            log2dev('Manual corrected segmentation will be loaded','INFO',0,'hMainGui', 'statusbar',{0,5,2});
        end


    else
        execTDep = server.getMessageParameter(execMessageUID,'queue','dependences');
        [~,clabels,~] = RetrieveData2Load(execTDep);        
        
        if isempty(clabels)
            log2dev('Manual corrected segmentation has not been found. Deselect the option [Use corrected segmentation]','INFO');
            return;
        else
            log2dev('Automatic corrected segmentation will be loaded','INFO',0,'hMainGui', 'statusbar',{0,5,2});
        end
        
        %corrected_segmentation_file = [stgObj.data_analysisindir,'/SegResultsCorrected'];
        %possibly substitute with hasModule ecc..
        %if(exist([corrected_segmentation_file,'.mat'],'file'))
        %    local_use_corrections = 1;
        %else
        %    log2dev('No Corrections found. Please create corrected segmentation results before','INFO');
        %    return;
        %end
    end
end

%if user decided to apply cropping crop CLabels here
if(isfield(tmpStgObj,'use_polygon_crop')) %backwards compatability
    if tmpStgObj.use_polygon_crop
        log2dev('Polygon mask will be loaded','INFO',0,'hMainGui', 'statusbar',{0,5,4});
        
        execTDep = {'POLYMASK_FILE'};
        [~,polymask] = RetrieveData2Load(execTDep);
        
        if isempty(polymask)
            log2dev('Polygonal mask has not been found. Deselect the option [Use polygonCrop]','INFO');
            return;
        else
            log2dev('Polygonal mask will be loaded','INFO',0,'hMainGui', 'statusbar',{0,6,2});
        end
            
            
        
        execTDep = server.getMessageParameter(execMessageUID,'queue','dependences');
        [~,~,image] = RetrieveData2Load(execTDep);        
        
        
        [~, cropped_CellLabelIm] = PolygonCrop(image,clabels,polymask);
        
        % Overwrite original clabels
        clabels = cropped_CellLabelIm;
        
        %if(exist([stgObj.data_analysisindir,'/PoligonalMask.mat'],'file'))
        %    tmpMaskObj = load([stgObj.data_analysisindir,'/PoligonalMask']);
        %    [~, cropped_CellLabelIm] = PolygonCrop(tmpSegObj.RegIm,tmpSegObj.CLabels,tmpMaskObj.polygonal_mask);
        %    tmpSegObj.CLabels = cropped_CellLabelIm;
        %else
        %    log2dev('No Polygon Mask Found. Please create one in case you want to crop the skeletons','INFO');
        %    return;
        %end
    end
end

%% Skeleton routine
% preparing directory to store files
if exist([stgObj.data_analysisoutdir,'/skeletons'],'dir')
    outputpath = [stgObj.data_analysisoutdir,'/skeletons_',datestr(now(),30)];
   
else
    outputpath = [stgObj.data_analysisoutdir,'/skeletons'];
end
mkdir(outputpath);

% compute max number of frames to generate
frame_no = size(clabels,3);
log2dev('Generating skeletons','INFO',0,'hMainGui', 'statusbar',{0,frame_no+1,1});

% Loop over each single frame and generate the skeleton
for i = 1:frame_no
    %to make apply the transformation we need double
    cell_lables = double(clabels(:,:,i));
    %given that every cell has a different label
    %we can compute the boundaries by computing 
    %where the gradient changes
    [gx,gy] = gradient(cell_lables);
    cell_outlines = (cell_lables > 0) & ((gx.^2+gy.^2)>0);
    %to see intermediate results uncomment
    %time point suffix with 3 digits (e.g. 001)
    time_point_str = num2str(i,'%03.f');
    %output skeleton as png image
    output_path = outputpath;
    output_file_name = strcat('/frame_',time_point_str,'.png');
    output_fullpath = strcat(output_path,output_file_name);
    imwrite(cell_outlines,output_fullpath);
    %% Saving results
    stgObj.AddResult('Skeletons',strcat('skeletons_path_',num2str(i)),output_fullpath);
    log2dev('Generating skeletons','INFO',0,'hMainGui', 'statusbar',{0,frame_no,frame_no+1});
end
%progressbar(1);
% -------------------------------------------------------------------------
%% Output formatting
% Each single output need to be described in order to be used for variable exportation.
% ARGOUT variable is a structure object
% argout(1...).description = char();
% argout(1...).ref = variable reference;
% argout(1...).object = undefined;
% First output variable
% -------------------------------------------------------------------------
argout(1).description = 'Skeletons file path';
argout(1).ref = varargin(1);
argout(1).object = output_path;
% -------------------------------------------------------------------------
argout(2).description = 'Settings associated module instance execution';
argout(2).ref = varargin(2);
argout(2).object = input_args{strcmp(input_args(:,1),'ExecutionSettingsHandle'),2};
% -------------------------------------------------------------------------
%% Status execution update
status = 0;
end




