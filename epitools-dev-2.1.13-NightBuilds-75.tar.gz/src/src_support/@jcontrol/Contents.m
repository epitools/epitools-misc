% @JCONTROL
%
% Files
%   delete     - method overloaded for the JCONTROL class
%   get        - method overloaded for JCONTROL class
%   getappdata - function overloaded for JCONTROL class
%   isappdata  - function oveloaded for the JCONTROL class
%   jcontrol   - constructor for JCONTROL class
%   rmappdata  - function oveloaded for the JCONTROL class
%   set        - method overloaded for JCONTROL class
%   setappdata - function overloaded for JCONTROL class
%   subsasgn   - method overloaded for JCONTROL class
%   subsref    - method overloaded for jcontrol class
%   ancestor   - function overloaded as JCONTROL method
