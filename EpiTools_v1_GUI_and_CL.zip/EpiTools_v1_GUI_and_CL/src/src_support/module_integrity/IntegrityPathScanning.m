function [ arrayFoundFiles ] = IntegrityPathScanning( path, filepattern, filetype )
%INTEGRITYPATHSCANNING Summary of this function goes here
%   Detailed explanation goes here

% In case file type is not provided by the user, do not limit search to a
% specific file type, but consider all.
if nargin < 3
    filetype = 'all'
end




end

